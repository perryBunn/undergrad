import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * A border of our world, to cover the left and right edges.
 * 
 * @author Michael Kölling
 * @version 1.0
 */
public class Border extends Actor
{
    /**
     * Act - nothing to do. This object does not do anything.
     */
    public void act() 
    {
    }    
}
